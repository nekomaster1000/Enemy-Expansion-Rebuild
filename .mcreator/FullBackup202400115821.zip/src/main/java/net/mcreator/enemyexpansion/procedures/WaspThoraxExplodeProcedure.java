package net.mcreator.enemyexpansion.procedures;

public class WaspThoraxExplodeProcedure {
	public static void execute() {
	}
}
