package net.mcreator.enemyexpansion.procedures;

public class MeatureEatSizeProcedure {
	public static double execute() {
		return 1;
	}
}
